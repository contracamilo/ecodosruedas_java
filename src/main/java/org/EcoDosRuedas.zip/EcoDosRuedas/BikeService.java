package org.EcoDosRuedas;

public class BikeService {
    public static void readBikes() {
        BikeDataAccess.readBikeDB();
    }
}
