package org.EcoDosRuedas;

public class MotorBikeService {
    public static void readMotorBikes() {
        MotorBikeDataAccess.readMotorBikeDB();
    }
}
